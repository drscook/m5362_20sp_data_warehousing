


drop table if exists raw_country_name_fix cascade;
create table raw_country_name_fix (
	orig varchar(60) not null
	, repl varchar(60) not null
	, unique (orig)
	, primary key (orig, repl)
);



drop table if exists raw_entity_name_fix cascade;
create table raw_entity_name_fix (
	orig varchar(255) not null
	, repl varchar(255) not null
	, unique (orig)
	, primary key (orig, repl)
);



drop table if exists raw_city cascade;
create table raw_city (
	id int
	, city_name varchar(60) not null
	, subcountry_name varchar(60) not null
	, country_name varchar(60) not null
	, unique (city_name, subcountry_name, country_name)
	, primary key (id)
);



drop table if exists raw_country_data cascade;
create table raw_country_data (
	country_name varchar(60) not null
	, region_name varchar(60) not null
	, population bigint null
	, area bigint null
	, population_density float null
	, coastline float null
	, net_migration float null
	, infant_mortality float null
	, gdp int null
	, literacy float null
	, phones float null
	, arable float null
	, crops float null
	, other float null
	, climate float null
	, birthrate float null
	, deathrate float null
	, agriculture float null
	, industry float null
	, service float null
	, primary key (country_name)
);



drop table if exists raw_entity cascade;
create table raw_entity (
	name varchar(255) not null
	, type varchar(8) not null
	, city_name varchar(60) null
	, subcountry_name varchar(60) null
	, country_name varchar(60) null
	, primary key (name)
);


drop table if exists raw_project cascade;
create table raw_project (
	un_id varchar(68) not null
	, title varchar(258) not null
	, site varchar(60) null
	, repeats int default 1
	, primary key (un_id)
	, unique (title)
);


drop table if exists raw_project_entity cascade;
create table raw_project_entity (
	un_id varchar(68) not null
	, entity_name varchar(255) not null
	, n int null
	--, primary key (un_id, entity_name)
);


