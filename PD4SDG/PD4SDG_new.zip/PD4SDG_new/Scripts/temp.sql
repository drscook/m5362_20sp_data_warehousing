drop table if exists t2 cascade;
create table t2 as (
	select
		D.id as project_id
		, D.un_id
		, C.entity_name
	from (		
		select 
			A.un_id
			, coalesce(B.repl, A.entity_name) as entity_name 
		from
			raw_project_entity A
		left join
			entity_name_fix B
		on
			A.entity_name = B.orig
		) as C
	left join
		project as D
	on
		C.un_id = D.un_id
);

select
	A.*
	, B.*
from
	t2 as A
left join
	entity as B
on
	A.entity_name = B.name
;



where
	project_id is null
	or un_id is null
	or entity_name is null
;


