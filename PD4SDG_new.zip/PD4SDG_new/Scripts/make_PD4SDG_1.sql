/*
Data Sources



drop table if exists raw_country cascade;
create table raw_country (  -- source: http://www.geonames.org/
	geonameid int primary key
	, country_code varchar(2) not null unique
	, iso3 varchar(3) not null unique
	, iso_numeric int not null
	, fips varchar(2) null
	, country varchar(70) not null unique
	, capital varchar(70) null
	, area float not null                    -- (in sq km)
	, population bigint not null
	, continent varchar(2) not null
	, tld varchar(3) null
	, currency_code varchar(3) null
	, currency_name varchar(16) null
	, phone varchar(16) null
	, postal_code_format varchar(70) null
	, postal_code_regex varchar(175) null
	, languages varchar(100) null
	, neighbours varchar(70) null
	, equivalentfipscode varchar(3) null
);



drop table if exists raw_admin1 cascade;
create table raw_admin1 (  -- source: http://www.geonames.org/
	geonameid int primary key
	, code varchar(11) not null
	, admin1 varchar(70) null
	, asciiname varchar(70) null
);



drop table if exists raw_city cascade;
create table raw_city (  -- source: http://www.geonames.org/
	geonameid int          					-- 'integer id of record in geonames database'
	, name varchar(70) null              	-- 'name of geographical point (utf8) varchar(200)'
	, asciiname varchar(70) null         	-- 'name of geographical point in plain ascii characters, varchar(200)'
	, alternatenames varchar(2600) null  	--'alternatenames, comma separated, ascii names automatically transliterated, convenience attribute from alternatename table, varchar(10000)'
	, latitude float not null          		-- 'latitude in decimal degrees (wgs84)'
	, longitude float not null         		-- 'longitude in decimal degrees (wgs84)'
, feature_class varchar(1) null     		-- 'see http://www.geonames.org/export/codes.html, char(1)'
	, feature_code varchar(5) null      	-- 'see http://www.geonames.org/export/codes.html, varchar(10)'
	, country_code varchar(2) not null      -- 'ISO-3166 2-letter country code, 2 characters'
	, cc2 varchar(5) null               	-- 'alternate country codes, comma separated, ISO-3166 2-letter country code, 200 characters'
	, admin1_code varchar(30) null       	-- 'fipscode (subject to change to iso code), see exceptions below, see file admin1Codes.txt for display names of this code'
	, admin2_code varchar(30) null	       	-- 'code for the second administrative division, a county in the US, see file admin2Codes.txt; varchar(80)'
	, admin3_code varchar(30) null  	 	-- 'code for third level administrative division, varchar(20)'
	, admin4_code varchar(30) null      	-- 'code for fourth level administrative division, varchar(20)'
	, population bigint not null        	-- 'bigint (8 byte int)'
	, elevation varchar(4) null        		-- 'in meters, integer'
	, dem bigint null               		-- 'digital elevation model, srtm3 or gtopo30, average elevation of 3''x3'' (ca 90mx90m) or 30''x30'' (ca 900mx900m) area in meters, integer. srtm processed by cgiar/ciat.'
	, timezone varchar(30) not null         -- 'the iana timezone id (see file timeZone.txt) varchar(40)'
	, modification_date date not null 		-- 'date of last modification in yyyy-MM-dd format'
);



drop table if exists raw_entity_type cascade;
create table raw_entity_type (   -- source: Dr. Anne Egelston
	code varchar(8) primary key
	, name varchar(29) not null unique
);
insert into raw_entity_type (code, name)
values
	('Ngo', 'Non-Governmental Organization')
	, ('Priv', 'Private Sector')
	, ('Acad', 'Academic Institution')
	, ('Subgov', 'Sub-National Government')
	, ('Sci', 'Scientific Community')
	, ('Natgov', 'National Government')
	, ('Intergov', 'Inter-National Government')
	, ('Un', 'United Nations Entity')
	, ('Supgov', 'Supra-National Government')
;



drop table if exists raw_entity_name_fix cascade;
create table raw_entity_name_fix (  -- source: Dr. Anne Egelston
	orig varchar(255) not null
	, repl varchar(255) not null
);



drop table if exists raw_entity cascade;
create table raw_entity (    -- source: Dr. Anne Egelston
	id int primary key
	, name varchar(255) not null unique
	, type varchar(8) not null
	, geonameid int not null
	, country_orig varchar(70) null
	, subcountry_orig varchar(70) null
	, city_orig varchar(70) null
);



drop table if exists raw_project cascade;
create table raw_project (  -- https://sustainabledevelopment.un.org/partnerships/
	un_id varchar(68) not null unique
	, title varchar(258) not null
	, site varchar(60) null
	, reps int default 1
);



drop table if exists raw_project_entity cascade;
create table raw_project_entity (  https://sustainabledevelopment.un.org/partnerships/
	un_id varchar(68) not null
	, entity_name varchar(255) not null
	, reps int null
);





-- raw tables created above, load data
