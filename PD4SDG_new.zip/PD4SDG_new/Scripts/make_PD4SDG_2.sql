


drop table if exists country cascade;
create table country (like raw_country including all);
insert into country
    -- string cleaning
	select
        geonameid as geonameid
        , initcap(trim(country_code)) as country_code
        , initcap(trim(iso3)) as iso3
        , iso_numeric as iso_numeric
        , initcap(trim(fips)) as fips
        , initcap(trim(country)) as country
        , initcap(trim(capital)) as capital
        , area as area
        , population as population
        , initcap(trim(continent)) as continent
        , initcap(trim(tld)) as tld
        , initcap(trim(currency_code)) as currency_code
        , initcap(trim(currency_name)) as currency_name
        , initcap(trim(phone)) as phone
        , initcap(trim(postal_code_format)) as postal_code_format
        , initcap(trim(postal_code_regex)) as postal_code_regex
        , initcap(trim(languages)) as languages
        , initcap(trim(neighbours)) as neighbours
        , initcap(trim(equivalentfipscode)) as equivalentfipscode
    from
        raw_country
;



drop table if exists admin1 cascade;
create table admin1 (like raw_admin1 including all);
alter table admin1 add column country_code varchar(2) not null, add column admin1_code varchar(8) not null;
insert into admin1
	-- split code in country_code and admin1_code
	select
		A.*
		, substring(A.code, 1, 2) as country_code
		, substring(A.code, 4) as admin1_code
	from (
		-- string cleaning
		select
			geonameid
			, initcap(trim(code)) as code
			, initcap(trim(coalesce(admin1, asciiname))) as admin1
			, initcap(trim(coalesce(asciiname, admin1))) as asciiname
		from
			raw_admin1
		) as A
;
alter table admin1
	alter column admin1 set not null
	, alter column asciiname set not null
	, add unique (country_code, admin1_code)
	, add constraint admin1_fk foreign key (country_code) references country(country_code)
;



drop table if exists city cascade;
create table city (like raw_city including all);
alter table city add column srt int not null, add column reps int not null;
insert into city
	-- remove duplicate (country_code, admin1_code) by keeping one with largest population (break ties with modification_date)
	select
		*
	from (
		-- find duplicate (country_code, admin1_code) and rank by largest population (break ties with modification_date)
		select
			*
			, row_number() over (partition by country_code, admin1_code, name order by population, modification_date desc) as srt
			, count(1)     over (partition by country_code, admin1_code, name) as reps
		from (
			-- string cleaning
			select
				geonameid as geonameid
				, initcap(trim(coalesce(name, asciiname))) as name
				, initcap(trim(coalesce(asciiname, name))) as asciiname
				, initcap(trim(alternatenames)) as alternatenames
				, latitude as latitude
				, longitude as longitude
				, initcap(trim(feature_class)) as feature_class
				, initcap(trim(feature_code)) as feature_code
				, initcap(trim(country_code)) as country_code
				, initcap(trim(cc2)) as cc2
				, initcap(trim(admin1_code)) as admin1_code
				, initcap(trim(admin2_code)) as admin2_code
				, initcap(trim(admin3_code)) as admin3_code
				, initcap(trim(admin4_code)) as admin4_code
				, population as population
				, initcap(trim(elevation)) as elevation
				, dem as dem
				, initcap(trim(timezone)) as timezone
				, modification_date as modification_date
			from
				raw_city
			) as A
		) as B
	where
		srt = 1
;
alter table city
	alter column name set not null
	, alter column asciiname set not null
	, add unique (country_code, name, admin1_code)
	, add primary key (geonameid)
	, add constraint city_fk1 foreign key (country_code) references country(country_code)
	--, add constraint city_fk2 foreign key (country_code, admin1_code) references admin1(country_code, admin1_code)
;



drop table if exists entity_type cascade;
create table entity_type (like raw_entity_type including all);
insert into entity_type
	-- string cleaning
    select
		initcap(trim(code)) as code
		, initcap(trim(name)) as name
    from
        raw_entity_type
;




drop table if exists entity_name_fix cascade;
create table entity_name_fix (like raw_entity_name_fix including all);
insert into entity_name_fix
	-- remove duplicate (orig, repl)
	select
		orig
		, repl
	from (
		-- string cleaning
		select
			initcap(trim(orig)) as orig
			, initcap(trim(repl)) as repl
		from
			raw_entity_name_fix
		) as A
	group by
		1, 2
;
alter table entity_name_fix add primary key (orig);




drop table if exists entity cascade;
create table entity (like raw_entity including all);
insert into entity
	-- string cleaning
    select
		id
		, initcap(trim(name)) as name
		, initcap(trim(type)) as type
		, geonameid
		, initcap(trim(country_orig)) as country_orig
		, initcap(trim(subcountry_orig)) as subcountry_orig
		, initcap(trim(city_orig)) as city_orig
    from
        raw_entity
;
alter table entity add constraint entity_fk1 foreign key (type) references entity_type(code);



drop table if exists project cascade;
create table project (like raw_project including all);
insert into project
	-- string cleaning
    select
        initcap(trim(un_id)) as un_id
        , initcap(trim(title)) as title
        , initcap(trim(site)) as site
        , reps as reps
    from
        raw_project
;



drop table if exists project_entity cascade;
create table project_entity as (
with C as(
	-- apply name_fix
	select
		A.un_id
		, coalesce(B.repl, A.entity_name) as entity_name
	from (
		-- string cleaning
		select
			initcap(trim(un_id)) as un_id
			, initcap(trim(entity_name)) as entity_name
		from
			raw_project_entity
		) as A
	left join
		entity_name_fix as B
	on
		A.entity_name = B.orig
)
-- get entity_id via join with entity
select
	D.un_id
	, E.id as entity_id
	, D.entity_name
from (
	-- remove duplicate (un_id, entity_name)
	select
		un_id
		, entity_name
	from
		C
	group by
		1, 2		
	) D
left join
	entity as E
on
	D.entity_name = E.name
);
alter table project_entity
	add constraint project_entity_fk1 foreign key (un_id) references project(un_id)
	, add constraint project_entity_fk2 foreign key (entity_id) references entity(id)
--	, add primary key (un_id, entity_id);
;




