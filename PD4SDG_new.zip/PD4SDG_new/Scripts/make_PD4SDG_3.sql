drop table if exists project_entity_nomatch cascade;
create table project_entity_nomatch as (
	select
		*
	from
		project_entity
	where
		entity_id is null
);



drop table if exists entity_country cascade;
create table entity_country as (
	select
		A.*
		, B.geonameid as country_geonameid
		, B.country_code as country_code
	from
		entity as A
	left join
		country as B
	on
		A.country_orig = B.country
);



drop table if exists entity_country_nomatch cascade;
create table entity_country_nomatch as (
	select
		*
	from
		entity_country
	where
		country_geonameid is null
);


drop table if exists entity_country_match cascade;
create table entity_country_match as (
	select
		*
	from
		entity_country
	where
		country_geonameid is not null
);




drop table if exists entity_country_match_city cascade;
create table entity_country_match_city as (
	select
		A.*
		, B.geonameid as city_geonameid
	from
		entity_country_match as A
	left join
		city as B
	on
		A.country_code = B.country_code
		and A.city_orig = B.name
);



drop table if exists entity_country_match_city_nomatch cascade;
create table entity_country_match as (
	select
		*
	from
		entity_country_match_city
	where
		city_geonameid is null
);



drop table if exists entity_country_match_city_match cascade;
create table entity_country_match as (
	select
		*
	from
		entity_country_match_city
	where
		city_geonameid is not null
);
