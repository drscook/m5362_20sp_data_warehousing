
drop table if exists entity_data_full cascade;
create table entity_data_full as (
	select
		C.*
		, D.name as city_name
		, D.admin1_name
		, D.admin1_geonameid
		, D.country_name
		, D.country_geonameid
		, D.country_code
		, D.latitude
		, D.longitude
		, D.population
	from (
		select
			A.*
			, coalesce(B.num_projects, 0) as num_projects
		from
			entity_data as A
		left join (
			select
				entity_id
				, count(1) as num_projects
			from
				project_entity
			group by
				entity_id
			) as B
		on
			A.id = B.entity_id
		) as C
	left join
		world as D
	on
		C.geonameid = D.geonameid
);





drop table if exists A cascade;
create table A as (
	select
		B. *
		, coalesce(A.num_projects, 0) as num_projects
	from (
		select
			entity_id
			, count(1) as num_projects
		from
			project_entity
		group by
			entity_id
		) as A
	right join
		entity_data as B
	on
		A.entity_id = B.id
	order by
		id
) inherits (entity_data);



-- drop table if exists T cascade;
-- create table T (like entity_data including all);
alter table entity_data add column num_projects int;
insert into T
	select
		A.*
		, coalesce(B.num_projects, 0) as num_projects
	from
		entity_data as A
	left join (
		select
			entity_id
			, count(1) as num_projects
		from
			project_entity
		group by
			entity_id
		) as B
	on
		A.id = B.entity_id
;








select
	A. *
	, coalesce(B.num_projects, 0) as num_projects
from
	entity_data as A
left join (
	select
		entity_id
		, count(1) as num_projects
	from
		project_entity
	group by
		entity_id
	) as B
on
	A.id = B.entity_id
order by
	id






drop table if exists project_entity_nomatch cascade;
create table project_entity_nomatch as (
	select
		*
	from
		project_entity
	where
		entity_id is null
);



drop table if exists entity_country cascade;
create table entity_country as (
	select
		A.*
		, B.geonameid as country_geonameid
		, B.country_code as country_code
	from
		entity_data as A
	left join
		country as B
	on
		A.country_orig = B.country
);



drop table if exists entity_country_nomatch cascade;
create table entity_country_nomatch as (
	select
		*
	from
		entity_country
	where
		country_geonameid is null
);


drop table if exists entity_country_matches cascade;
create table entity_country_matches as (
	select
		*
	from
		entity_country
	where
		country_geonameid is not null
);




drop table if exists entity_city cascade;
create table entity_city as (
	select
		A.*
		, B.geonameid as city_geonameid
	from
		entity_country_matches as A
	left join
		city as B
	on
		A.country_code = B.country_code
		and A.city_orig = B.name
);



drop table if exists entity_city_nomatch cascade;
create table entity_city_nomatch as (
	select
		*
	from
		entity_city
	where
		city_geonameid is null
);



drop table if exists entity_city_matches cascade;
create table entity_city_matches as (
	select
		*
	from
		entity_city
	where
		city_geonameid is not null
);
